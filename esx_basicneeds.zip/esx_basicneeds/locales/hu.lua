Locales['hu'] = {
  ['used_bread'] = 'Megettél egy kenyeret.',
  ['used_water'] = 'Megittál egy vizet.',
}