Locales['sv'] = {
  ['used_bread'] = 'du käkade upp en bit bröd',
  ['used_water'] = 'du drack upp en vattenflaska',
}