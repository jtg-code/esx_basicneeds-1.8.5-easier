Locales['de'] = {
  ['used_eat'] = 'du hast 1x %s gegessen',
  ['used_drink'] = 'du hast 1x %s getrunken',
}