Locales['en'] = {
  ['used_eat'] = 'you have used 1x %s',
  ['used_drink'] = 'you have used 1x %s',
}