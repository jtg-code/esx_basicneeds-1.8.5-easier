Config = {}
Config.Locale = 'en'
Config.Visible = true

Config.Eat {
    ["bread"] = 200000
}

Config.Drink {
    ["water"] = 200000
}