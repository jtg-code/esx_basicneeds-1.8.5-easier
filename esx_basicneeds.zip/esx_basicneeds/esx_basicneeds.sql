

INSERT INTO `items` (`name`, `label`, `weight`) VALUES
	('bread', 'Bread', 1),
	('water', 'Water', 1)
;
